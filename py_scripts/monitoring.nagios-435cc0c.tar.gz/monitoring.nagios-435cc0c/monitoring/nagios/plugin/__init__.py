from monitoring.nagios.plugin.base import NagiosPlugin
from monitoring.nagios.plugin.snmp import NagiosPluginSNMP
from monitoring.nagios.plugin.secureshell import NagiosPluginSSH
from monitoring.nagios.plugin.database import NagiosPluginMSSQL
from monitoring.nagios.plugin.wmi import NagiosPluginWMI
from monitoring.nagios.plugin.http import NagiosPluginHTTP
from monitoring.nagios.plugin.database_db2 import NagiosPluginDB2
