#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-
"""Copyright (C) Faurecia <http://www.faurecia.com/>.

 Permission is hereby granted, free of charge, to any person obtaining
 a copy of this software and associated documentation files (the "Software"),
 to deal in the Software without restriction, including without limitation
 the rights to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included
 in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 Application: DB2 monitoring _ MSSQL database module.

 Author : RAFATI Saeed, saeed.rafati-ext@faurecia.com

 Version: 1.0.0.0

 Date of last change: 11 July 2018

 This plugin provides the Nagios arguments for ProbeDB2 init class to connect to the DB2 and fetch the information

"""



import ibm_db
import logging
from monitoring.nagios.plugin import NagiosPlugin
from monitoring.nagios.probes import ProbeDB2
import traceback
import sys


logger = logging.getLogger('plugin.database_db2')


class NagiosPluginDB2(NagiosPlugin):
    """Base for a standard SSH Nagios plugin"""
    def __init__(self, *args, **kwargs):
        super(NagiosPluginDB2, self).__init__(*args, **kwargs)

        try:
	    """Create an object of ProbeDB2 class with arguments"""
            self.db2 = ProbeDB2(hostaddress=self.options.hostname,
                                    username=self.options.username,
                                    password=self.options.password,
                                    database=self.options.database,
                                    login_timeout=self.options.login_timeout,
				    port=self.options.port)
        except Exception as e:
	    logger.debug("Cannot initialize the database connection object. \n %s" % str(e))
	    raise e


    """Basic class for nagios."""

    def define_plugin_arguments(self):
        super(NagiosPluginDB2,self).define_plugin_arguments()
	

        self.required_args.add_argument('-u', '--user',
					required=True,
					help='database username.',
					dest='username')
        self.required_args.add_argument('-p', '--password',
					required=True,
					help='database password.',
					dest='password')
        self.required_args.add_argument('-d', '--database',
					required=True,
					help='database name',
					dest='database')
        self.required_args.add_argument('-pr', '--port',
					type = int,
					required=True,
					help='port number',
					dest='port')
        self.required_args.add_argument('-t', '--timeout',
					default=10,
					type=int,
					required=False,
					help='query timeout, default 10s',
					dest='login_timeout')



    def connect_db2(self):
	"""Connect to the DB"""
	try:
	    self.db2.connect_db2()
	except Exception as e:
            raise e 

    def execute_query(self, sql_query, params_list):
        """Execute a SQL query and fetch all data."""
        logger.debug(sql_query)
	try:
	    query_result = self.db2.execute_query(sql_query, params_list)
            return query_result
	except Exception as e:
            raise e


    def close_connection(self):
        """Close the database connection."""
	try:
            self.db2.close_connection()
	except Exception as e:
            raise e

