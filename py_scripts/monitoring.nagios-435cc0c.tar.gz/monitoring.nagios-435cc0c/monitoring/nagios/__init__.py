import monitoring.nagios.logger

__version__ = '1.3.8'
