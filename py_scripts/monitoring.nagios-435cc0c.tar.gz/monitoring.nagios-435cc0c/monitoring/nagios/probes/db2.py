# -*- coding: utf-8 -*-


"""Copyright (C) Faurecia <http://www.faurecia.com/>.

 Permission is hereby granted, free of charge, to any person obtaining
 a copy of this software and associated documentation files (the "Software"),
 to deal in the Software without restriction, including without limitation
 the rights to use, copy, modify, merge, publish, distribute, sublicense,
 and/or sell copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included
 in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 Application: DB2 monitoring _ MSSQL probe module. 

 Author : RAFATI Saeed, saeed.rafati-ext@faurecia.com

 Version: 1.0.0.0

 Date of last change: 11 July 2018

 Documentation about this plugin can be found on the internet here :

 https://github.com/ibmdb/python-ibmdb/wiki/APIs

 History: Following DB2 probe module is used to connect to the DB2 database

"""

import ibm_db
import logging
from monitoring.nagios.probes import Probe

logger = logging.getLogger('monitoring.nagios.probes.db2')

class ProbeDB2(Probe):
    """
    A DB2 Server probe.

    :param hostaddress: The host to connect to.
    :type hostaddress: str
    :param username: Login user name.
    :type username: str
    :param password: Login user password.
    :type password: str
    :param database: Database to connect to, by default selects the database which is set as default for specific user.
    :type database: str
    :param login_timeout: Timeout for connection and login in seconds, default is 10 secs.
    :type login_timeout: int
    :param port: Database port number.
    :type port: int
    """
    def __init__(self, hostaddress, username, password, port, database, login_timeout):
        super(ProbeDB2, self).__init__()

        self.hostaddress = hostaddress
        self.username = username
        self._password = password
        self.database = database
        self.login_timeout = login_timeout
	self.port = port

        logger.debug('Establishing DB2 server connection to %s '
                     'on database %s with user '
                     '%s...'%(self.hostaddress, self.database, self.username))


	"""We need to define a complete database connection string for a direct TCP/IP connection."""
    	"""https://www.ibm.com/support/knowledgecenter/en/SSEPGG_10.1.0/com.ibm.swg.im.dbclient.python.doc/doc/t0054368.html"""

	self.connection_string = 'DATABASE=%s;'+\
                        'HOSTNAME=%s;'+\
                        'PORT=%d;'+\
                        'PROTOCOL=TCPIP;'+\
                        'UID=%s;'+\
                        'PWD=%s;'+\
                        'ConnectTimeout=%d'



    def connect_db2(self):
        try:
	    """Connect to the DB"""
            self._db_connection = ibm_db.connect(self.connection_string  % (self.database,
                                                self.hostaddress,
                                                self.port,
                                                self.username,
                                                self._password,
                                                self.login_timeout),"","")
	    logger.debug('End of prob init !!!')
	except Exception as e:
	    raise e
                   


    def execute_query(self, sql_query, params_list):
        """Creates a prepared SQL statement which can include 0 or more parameter markers (? characters) """
	try:	
	    query_statement = ibm_db.prepare(self._db_connection, sql_query)

            if  params_list is not None:
        	"""Explicitly bind parameters"""
        	for key,item in enumerate(params_list):
		    """Binds a  variable to an SQL statement parameter returnned by ibm_db.prepare(). Arguments are: """
		    """stmt - A prepared statement returned from ibm_db.prepare() """
		    """parameter-number - The 1-indexed position of the parameter in the prepared statement """
		    """variable - A Python variable to bind to the parameter specified by parameter-number"""
            	    ibm_db.bind_param(query_statement, key+1, item)

            query_result = ibm_db.execute(query_statement)
            logger.debug("DB2 query executed correctly.")
            return query_statement
        except Exception as e:
	    logger.debug("Cannot execute the SQL query.")
	    logger.debug(" %s" % query_statement)
            raise e


    def close_connection(self):
        """Disconnect from DB"""
        try:
            ibm_db.close(self._db_connection)
            logger.debug("Close DB2 connection succeed")
        except Exception as e:
            raise e


