===============
Arguments types
===============

.. automodule:: monitoring.nagios.plugin.argument
    :members: 
