// +build !release

package version

func init() {
	version.Revision = "dev"
}
